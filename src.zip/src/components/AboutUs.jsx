import React from 'react'

const AboutUs = () => {
  return (
    <div className="container py-5">
      <div className="row">
        <div className="col-lg-10 mx-auto">

          {/* ABOUT SECTION */}
          <div className="about mb-5">
            <h1 className="fw-bolder text-capitalize text-center text-success mb-4">
               🌍 About Us
            </h1>

            <p className="fs-5 text-muted">
              We believe that travel is more than just visiting new places — it’s about creating memories, discovering cultures, and experiencing the beauty of the world in a meaningful way. Our mission is to inspire travelers to explore nature, cities, and hidden destinations with confidence and comfort.
            </p>

            <p className="fs-5 text-muted">
              With a passion for adventure and a love for storytelling, we bring together carefully curated destinations, helpful travel planning tools, and visually engaging experiences.
            </p>

            <p className="fs-5 text-muted">
              We focus on simplicity, reliability, and user-friendly design so that your travel planning feels effortless. Join us as we explore the world together — one journey, one story, and one unforgettable experience at a time.
            </p>
          </div>

          {/* OFFER SECTION */}
          <div className="offers ">
            <h2 className="fw-bold mb-4 text-success text-center">
              ✨ What We Offer
            </h2>

            <h4 className="fw-semibold mb-2">🧭 Destination Discovery</h4>
            <p className="text-muted mb-4">
              We help users discover beautiful cities and countries around the world. Our destination search allows travelers to explore places based on interest, location, and curiosity.
            </p>

            <h4 className="fw-semibold mb-2">🔍 Smart Search Experience</h4>
            <p className="text-muted mb-4">
              Our search functionality is designed to be fast, intuitive, and user-friendly, making travel planning smoother and more efficient.
            </p>

            <h4 className="fw-semibold mb-2">🎨 Clean & Minimal Design</h4>
            <p className="text-muted mb-4">
              We follow a clean and minimal design approach that keeps users focused and engaged while maintaining a modern and professional feel.
            </p>

            <h4 className="fw-semibold mb-2">📱 Responsive & User-Friendly Interface</h4>
            <p className="text-muted mb-4">
              Our platform works seamlessly across all devices, allowing users to plan trips anytime, anywhere without difficulty.
            </p>

            <h4 className="fw-semibold mb-2">🚀 Continuous Improvement</h4>
            <p className="text-muted mb-4">
              We continuously improve our platform based on user feedback, ensuring better performance and experience over time.
            </p>

            <h4 className="fw-semibold mb-2">🤝 Our Vision</h4>
            <p className="text-muted">
              Our vision is to become a trusted travel companion for explorers worldwide, inspiring confidence, curiosity, and excitement.
            </p>
          </div>

        </div>
      </div>
    </div>
  )
}

export default AboutUs
